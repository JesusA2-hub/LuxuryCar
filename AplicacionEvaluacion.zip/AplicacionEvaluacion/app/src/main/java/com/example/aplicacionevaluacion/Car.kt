package com.example.aplicacionevaluacion

import com.google.firebase.firestore.DocumentId

data class Car(
    @DocumentId
    val documentId: String? = null,

    var brand: String = "",
    var model: String = "",
    var year: Long = 0L,
    var price: Long = 0L,
    var seller: String = "",
    var legalStatus: String = "",
    var warranty: String = ""
)